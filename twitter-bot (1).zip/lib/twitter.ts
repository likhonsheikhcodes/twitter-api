import { TwitterApi } from "twitter-api-v2"

export async function getTwitterClient(accessToken: string) {
  return new TwitterApi(accessToken)
}

export async function getUserProfile(client: TwitterApi) {
  const user = await client.v2.me({
    "user.fields": ["public_metrics", "created_at", "description", "profile_image_url"],
  })
  return user.data
}

export async function getUserTweets(client: TwitterApi, userId: string, maxResults = 100) {
  const tweets = await client.v2.userTimeline(userId, {
    exclude: ["retweets", "replies"],
    max_results: maxResults,
    "tweet.fields": ["public_metrics", "created_at"],
  })
  return tweets.data.data
}

export async function postTweet(client: TwitterApi, content: string) {
  const tweet = await client.v2.tweet(content)
  return tweet.data
}

export async function scheduleTweet(client: TwitterApi, content: string, scheduledTime: Date) {
  // Note: Twitter API v2 doesn't support scheduling tweets directly.
  // This is a placeholder for future implementation or third-party service integration.
  console.log(`Tweet scheduled for ${scheduledTime.toISOString()}: ${content}`)
  return { id: "placeholder", text: content, scheduledTime }
}

export async function getFollowers(client: TwitterApi, userId: string, maxResults = 100) {
  const followers = await client.v2.followers(userId, { max_results: maxResults })
  return followers.data
}

export async function getTweetAnalytics(client: TwitterApi, tweetId: string) {
  const tweet = await client.v2.singleTweet(tweetId, {
    "tweet.fields": ["public_metrics", "non_public_metrics", "organic_metrics"],
  })
  return tweet.data
}

export function calculateEngagementRate(tweets: any[]) {
  const totalEngagements = tweets.reduce((sum, tweet) => {
    return sum + (tweet.public_metrics?.like_count || 0) + (tweet.public_metrics?.retweet_count || 0)
  }, 0)
  return ((totalEngagements / tweets.length) * 100).toFixed(2)
}

