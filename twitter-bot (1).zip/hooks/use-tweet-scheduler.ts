import { useState } from "react"
import { scheduleTweet } from "@/lib/twitter"

export function useTweetScheduler() {
  const [isScheduling, setIsScheduling] = useState(false)

  const scheduleTweetHandler = async (content: string, scheduledTime: Date) => {
    setIsScheduling(true)
    try {
      // In a real implementation, you'd pass the client here
      const result = await scheduleTweet(null as any, content, scheduledTime)
      setIsScheduling(false)
      return result
    } catch (error) {
      setIsScheduling(false)
      throw error
    }
  }

  return { scheduleTweet: scheduleTweetHandler, isScheduling }
}

