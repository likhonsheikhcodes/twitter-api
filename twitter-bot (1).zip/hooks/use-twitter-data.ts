import useSWR from "swr"
import { fetcher } from "@/lib/utils"

export function useTwitterData() {
  const { data, error, mutate } = useSWR("/api/twitter-data", fetcher, {
    refreshInterval: 60000, // Refresh every minute
  })

  return {
    data,
    isLoading: !error && !data,
    isError: error,
    mutate,
  }
}

