import { useState } from "react"
import { useTweetScheduler } from "@/hooks/use-tweet-scheduler"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"

export default function TweetScheduler() {
  const [content, setContent] = useState("")
  const [scheduledTime, setScheduledTime] = useState("")
  const { scheduleTweet, isScheduling } = useTweetScheduler()

  const handleSchedule = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!content || !scheduledTime) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      })
      return
    }

    try {
      await scheduleTweet(content, new Date(scheduledTime))
      toast({
        title: "Success",
        description: "Tweet scheduled successfully",
      })
      setContent("")
      setScheduledTime("")
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to schedule tweet",
        variant: "destructive",
      })
    }
  }

  return (
    <form onSubmit={handleSchedule} className="space-y-4">
      <Textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="What's happening?"
        maxLength={280}
      />
      <Input type="datetime-local" value={scheduledTime} onChange={(e) => setScheduledTime(e.target.value)} />
      <Button type="submit" disabled={isScheduling}>
        {isScheduling ? "Scheduling..." : "Schedule Tweet"}
      </Button>
    </form>
  )
}

