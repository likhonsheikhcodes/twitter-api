import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Twitter, Users, MessageCircle, Zap } from "lucide-react"
import { Line } from "react-chartjs-2"
import { formatNumber } from "@/lib/utils"

export default function OverviewTab({ data }) {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  return (
    <div className="space-y-8">
      <motion.div
        ref={ref}
        initial={{ opacity: 0, y: 20 }}
        animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
        transition={{ duration: 0.5 }}
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
      >
        <StatCard
          title="Followers"
          value={formatNumber(data.stats.followerCount)}
          icon={<Twitter className="h-4 w-4 text-blue-500" />}
        />
        <StatCard
          title="Following"
          value={formatNumber(data.stats.followingCount)}
          icon={<Users className="h-4 w-4 text-green-500" />}
        />
        <StatCard
          title="Tweets"
          value={formatNumber(data.stats.tweetCount)}
          icon={<MessageCircle className="h-4 w-4 text-purple-500" />}
        />
        <StatCard
          title="Engagement Rate"
          value={`${data.stats.engagementRate}%`}
          icon={<Zap className="h-4 w-4 text-yellow-500" />}
        />
      </motion.div>

      <Card>
        <CardHeader>
          <CardTitle>Tweet Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <Line
            data={data.tweetActivityData}
            options={{
              responsive: true,
              scales: {
                y: {
                  beginAtZero: true,
                },
              },
            }}
          />
        </CardContent>
      </Card>

      <RecentTweets tweets={data.recentTweets} />
    </div>
  )
}

function StatCard({ title, value, icon }) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
      </CardContent>
    </Card>
  )
}

function RecentTweets({ tweets }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Tweets</CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="space-y-4">
          {tweets.map((tweet) => (
            <li key={tweet.id} className="border-b pb-4 last:border-b-0">
              <p className="mb-2">{tweet.text}</p>
              <div className="flex justify-between text-sm text-gray-500">
                <span>{new Date(tweet.createdAt).toLocaleDateString()}</span>
                <div>
                  <span className="mr-4">❤️ {tweet.likes}</span>
                  <span>🔁 {tweet.retweets}</span>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  )
}

