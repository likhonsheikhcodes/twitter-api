import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Line } from "react-chartjs-2"
import { formatNumber } from "@/lib/utils"

export default function FollowersTab({ data }) {
  const followerGrowthData = {
    labels: data.followerGrowth.labels,
    datasets: [
      {
        label: "Follower Count",
        data: data.followerGrowth.data,
        fill: false,
        borderColor: "rgb(75, 192, 192)",
        tension: 0.1,
      },
    ],
  }

  return (
    <div className="space-y-8">
      <Card>
        <CardHeader>
          <CardTitle>Follower Growth</CardTitle>
        </CardHeader>
        <CardContent>
          <Line
            data={followerGrowthData}
            options={{
              responsive: true,
              scales: {
                y: {
                  beginAtZero: true,
                },
              },
            }}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Top Followers</CardTitle>
        </CardHeader>
        <CardContent>
          {data.topFollowers.map((follower) => (
            <div key={follower.id} className="flex items-center space-x-4 mb-4">
              <img
                src={follower.profile_image_url || "/placeholder.svg"}
                alt={follower.name}
                className="w-12 h-12 rounded-full"
              />
              <div>
                <p className="font-semibold">{follower.name}</p>
                <p className="text-sm text-gray-500">@{follower.username}</p>
                <p className="text-sm">{formatNumber(follower.followers_count)} followers</p>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}

