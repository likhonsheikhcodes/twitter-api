"use client"

import { useState } from "react"
import { useTwitterData } from "@/hooks/use-twitter-data"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import OverviewTab from "@/components/dashboard/overview-tab"
import EngagementTab from "@/components/dashboard/engagement-tab"
import FollowersTab from "@/components/dashboard/followers-tab"
import TweetsTab from "@/components/dashboard/tweets-tab"
import TweetScheduler from "@/components/dashboard/tweet-scheduler"
import UserProfile from "@/components/shared/user-profile"
import TweetComposer from "@/components/shared/tweet-composer"
import LoadingSpinner from "@/components/shared/loading-spinner"

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState("overview")
  const { data: twitterData, isLoading, isError, mutate } = useTwitterData()

  if (isLoading) return <LoadingSpinner />
  if (isError) return <div>Error loading dashboard data</div>

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-bold">Twitter Dashboard</h1>
        <UserProfile user={twitterData.user} />
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5 rounded-xl bg-gray-100 dark:bg-gray-800">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="engagement">Engagement</TabsTrigger>
          <TabsTrigger value="followers">Followers</TabsTrigger>
          <TabsTrigger value="tweets">Tweets</TabsTrigger>
          <TabsTrigger value="scheduler">Scheduler</TabsTrigger>
        </TabsList>
        <TabsContent value="overview">
          <OverviewTab data={twitterData} />
        </TabsContent>
        <TabsContent value="engagement">
          <EngagementTab data={twitterData} />
        </TabsContent>
        <TabsContent value="followers">
          <FollowersTab data={twitterData} />
        </TabsContent>
        <TabsContent value="tweets">
          <TweetsTab data={twitterData} />
        </TabsContent>
        <TabsContent value="scheduler">
          <TweetScheduler />
        </TabsContent>
      </Tabs>

      <div className="mt-8">
        <TweetComposer onTweetPosted={mutate} />
      </div>
    </div>
  )
}

