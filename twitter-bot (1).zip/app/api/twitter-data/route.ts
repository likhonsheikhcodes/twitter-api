import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { getTwitterClient, getUserProfile, getUserTweets, getFollowers, calculateEngagementRate } from "@/lib/twitter"

export async function GET() {
  const session = await getServerSession(authOptions)

  if (!session || !session.accessToken) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const client = await getTwitterClient(session.accessToken as string)
    const user = await getUserProfile(client)
    const tweets = await getUserTweets(client, user.id)
    const followers = await getFollowers(client, user.id)

    const tweetActivityData = {
      labels: tweets.map((tweet) => new Date(tweet.created_at as string).toLocaleDateString()),
      datasets: [
        {
          label: "Likes",
          data: tweets.map((tweet) => tweet.public_metrics?.like_count || 0),
          borderColor: "rgb(75, 192, 192)",
          tension: 0.1,
        },
        {
          label: "Retweets",
          data: tweets.map((tweet) => tweet.public_metrics?.retweet_count || 0),
          borderColor: "rgb(255, 99, 132)",
          tension: 0.1,
        },
      ],
    }

    const engagementRate = calculateEngagementRate(tweets)

    const data = {
      user: {
        id: user.id,
        name: user.name,
        username: user.username,
        profileImageUrl: user.profile_image_url,
        description: user.description,
        createdAt: user.created_at,
      },
      stats: {
        followerCount: user.public_metrics?.followers_count || 0,
        followingCount: user.public_metrics?.following_count || 0,
        tweetCount: user.public_metrics?.tweet_count || 0,
        engagementRate,
      },
      tweetActivityData,
      recentTweets: tweets.slice(0, 5).map((tweet) => ({
        id: tweet.id,
        text: tweet.text,
        createdAt: tweet.created_at,
        likes: tweet.public_metrics?.like_count || 0,
        retweets: tweet.public_metrics?.retweet_count || 0,
      })),
      tweets,
      topFollowers: followers.slice(0, 5).map((follower) => ({
        id: follower.id,
        name: follower.name,
        username: follower.username,
        profileImageUrl: follower.profile_image_url,
      })),
    }

    return NextResponse.json(data)
  } catch (error) {
    console.error("Error fetching Twitter data:", error)
    return NextResponse.json({ error: "Failed to fetch Twitter data" }, { status: 500 })
  }
}

