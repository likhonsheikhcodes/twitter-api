import Link from "next/link"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { Button } from "@/components/ui/button"
import { Github, Twitter } from "lucide-react"

export default async function Home() {
  const session = await getServerSession(authOptions)

  return (
    <div className="flex min-h-screen flex-col">
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none">
                  Welcome to Twitter Pilot
                </h1>
                <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                  Your all-in-one Twitter management and analytics platform. Get insights, schedule tweets, and grow
                  your audience.
                </p>
              </div>
              <div className="space-x-4">
                {session ? (
                  <Button asChild size="lg">
                    <Link href="/dashboard">
                      <Twitter className="mr-2 h-4 w-4" />
                      Go to Dashboard
                    </Link>
                  </Button>
                ) : (
                  <Button asChild size="lg">
                    <Link href="/auth/signin">
                      <Twitter className="mr-2 h-4 w-4" />
                      Sign in with Twitter
                    </Link>
                  </Button>
                )}
                <Button variant="outline" size="lg" asChild>
                  <a href="https://github.com/likhonsheikhcodes/twitter-api" target="_blank" rel="noopener noreferrer">
                    <Github className="mr-2 h-4 w-4" />
                    View on GitHub
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="border-t">
        <div className="container flex flex-col gap-2 py-4 md:flex-row md:items-center md:justify-between md:py-6">
          <p className="text-center text-sm leading-loose text-gray-500 md:text-left">
            Built with ❤️ by{" "}
            <a
              href="https://twitter.com/likhon_xyz"
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium underline underline-offset-4"
            >
              @likhon_xyz
            </a>
          </p>
          <p className="text-center text-sm text-gray-500 md:text-left">
            Powered by{" "}
            <a
              href="https://vercel.com"
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium underline underline-offset-4"
            >
              Vercel
            </a>
          </p>
        </div>
      </footer>
    </div>
  )
}

