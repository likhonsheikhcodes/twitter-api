import { getServerSession } from "next-auth/next"
import { redirect } from "next/navigation"
import { authOptions } from "@/lib/auth"
import { Button } from "@/components/ui/button"
import { Twitter } from "lucide-react"

export default async function SignIn() {
  const session = await getServerSession(authOptions)

  if (session) {
    redirect("/dashboard")
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-b from-blue-50 to-white dark:from-gray-900 dark:to-gray-800">
      <div className="mx-auto flex w-full max-w-[400px] flex-col items-center space-y-6 px-4">
        <div className="flex flex-col items-center space-y-2 text-center">
          <Twitter className="h-12 w-12 text-blue-500" />
          <h1 className="text-3xl font-bold">Welcome to Twitter Pilot</h1>
          <p className="text-gray-500 dark:text-gray-400">Sign in with Twitter to manage your account</p>
        </div>
        <Button
          className="w-full"
          size="lg"
          onClick={() => {
            window.location.href = "/api/auth/signin"
          }}
        >
          <Twitter className="mr-2 h-4 w-4" />
          Sign in with Twitter
        </Button>
      </div>
    </div>
  )
}

